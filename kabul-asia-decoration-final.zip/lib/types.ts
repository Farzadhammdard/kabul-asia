// Database types for Supabase
export interface Profile {
  id: string
  name: string
  email: string
  role: "Admin" | "Operator"
  created_at?: string
}

export interface Invoice {
  id: string
  user_id: string
  customer_name: string
  project_name: string
  service_type: "CNC" | "PVC" | "Cutting" | "Carpentry"
  area: number
  unit_price: number
  discount: number
  total: number
  date: string
  notes: string | null
  created_at?: string
}

export interface Expense {
  id: string
  user_id: string
  title: string
  amount: number
  category: "Materials" | "Rent & Electricity" | "General"
  date: string
  created_at?: string
}

export interface Employee {
  id: string
  user_id: string
  name: string
  base_salary: number
  attendance_days: number
  calculated_salary: number
  created_at?: string
}

// Service type labels in Persian
export const serviceTypeLabels: Record<string, string> = {
  CNC: "CNC",
  PVC: "PVC",
  Cutting: "برش",
  Carpentry: "نجاری",
}

// Category labels in Persian
export const categoryLabels: Record<string, string> = {
  Materials: "مواد اولیه",
  "Rent & Electricity": "اجاره و برق",
  General: "عمومی",
}

// Format number to Persian style
export function formatNumber(num: number): string {
  return new Intl.NumberFormat("fa-AF").format(Math.round(num))
}

// Calculate analytics
export function calculateAnalytics(invoices: Invoice[], expenses: Expense[], employees: Employee[]) {
  const totalRevenue = invoices.reduce((sum, inv) => sum + inv.total, 0)
  const totalExpenses = expenses.reduce((sum, exp) => sum + exp.amount, 0)
  const totalSalaries = employees.reduce((sum, emp) => sum + emp.calculated_salary, 0)
  const totalCosts = totalExpenses + totalSalaries
  const netProfit = totalRevenue - totalCosts
  const profitMargin = totalRevenue > 0 ? (netProfit / totalRevenue) * 100 : 0

  return {
    totalRevenue,
    totalExpenses: totalCosts,
    netProfit,
    profitMargin,
  }
}

// AI suggestions in Persian
export const aiSuggestions = [
  "با توجه به تحلیل داده‌ها، پیشنهاد می‌شود تمرکز بیشتری بر خدمات CNC داشته باشید زیرا بیشترین سود را دارد.",
  "هزینه‌های مواد اولیه ۴۰٪ از کل هزینه‌ها را تشکیل می‌دهد. مذاکره با تامین‌کنندگان جدید می‌تواند هزینه‌ها را کاهش دهد.",
  "حضور کارکنان در ماه جاری ۸۵٪ بوده است. برنامه‌ریزی بهتر می‌تواند بهره‌وری را افزایش دهد.",
]
