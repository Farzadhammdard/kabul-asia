"use client"

import { createContext, useContext, useEffect, useState, type ReactNode } from "react"
import { createClient } from "@/lib/supabase/client"
import type { Profile } from "@/lib/types"
import type { User } from "@supabase/supabase-js"

interface AuthContextType {
  user: User | null
  profile: Profile | null
  isLoading: boolean
  isAdmin: boolean
  signOut: () => Promise<void>
  refreshProfile: () => Promise<void>
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

function shouldIgnoreError(error: unknown): boolean {
  if (!error) return true
  if (error instanceof Error) {
    const msg = error.message.toLowerCase()
    return (
      error.name === "AbortError" ||
      msg.includes("abort") ||
      msg.includes("failed to fetch") ||
      msg.includes("network") ||
      msg.includes("cancelled")
    )
  }
  return false
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [profile, setProfile] = useState<Profile | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
    let isCancelled = false
    const supabase = createClient()

    const fetchProfile = async (userId: string): Promise<Profile | null> => {
      if (isCancelled) return null
      try {
        const { data, error } = await supabase.from("profiles").select("*").eq("id", userId).single()

        if (isCancelled) return null
        if (error) return null
        return data
      } catch (err) {
        if (!shouldIgnoreError(err)) {
          console.error("[v0] Profile error:", err)
        }
        return null
      }
    }

    const initAuth = async () => {
      try {
        const {
          data: { user: currentUser },
          error,
        } = await supabase.auth.getUser()

        if (isCancelled) return

        if (error || !currentUser) {
          setUser(null)
          setProfile(null)
          setIsLoading(false)
          return
        }

        setUser(currentUser)
        const profileData = await fetchProfile(currentUser.id)
        if (!isCancelled) {
          setProfile(profileData)
          setIsLoading(false)
        }
      } catch (err) {
        if (!shouldIgnoreError(err)) {
          console.error("[v0] Auth init error:", err)
        }
        if (!isCancelled) {
          setUser(null)
          setProfile(null)
          setIsLoading(false)
        }
      }
    }

    initAuth()

    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange(async (event, session) => {
      if (isCancelled) return

      const currentUser = session?.user ?? null
      setUser(currentUser)

      if (currentUser) {
        const profileData = await fetchProfile(currentUser.id)
        if (!isCancelled) setProfile(profileData)
      } else {
        setProfile(null)
      }

      if (!isCancelled) setIsLoading(false)
    })

    return () => {
      isCancelled = true
      subscription.unsubscribe()
    }
  }, [])

  const signOut = async () => {
    try {
      const supabase = createClient()
      await supabase.auth.signOut()
      setUser(null)
      setProfile(null)
    } catch (err) {
      if (!shouldIgnoreError(err)) {
        console.error("[v0] Sign out error:", err)
      }
    }
  }

  const refreshProfile = async () => {
    if (!user) return
    try {
      const supabase = createClient()
      const { data } = await supabase.from("profiles").select("*").eq("id", user.id).single()
      if (data) setProfile(data)
    } catch (err) {
      if (!shouldIgnoreError(err)) {
        console.error("[v0] Refresh error:", err)
      }
    }
  }

  if (!mounted) return null

  return (
    <AuthContext.Provider
      value={{
        user,
        profile,
        isLoading,
        isAdmin: profile?.role === "Admin",
        signOut,
        refreshProfile,
      }}
    >
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (!context) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}
