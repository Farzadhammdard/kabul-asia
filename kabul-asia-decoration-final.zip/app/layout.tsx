import type React from "react"
import type { Metadata, Viewport } from "next"
import { Geist, Geist_Mono } from "next/font/google"
import { Vazirmatn } from "next/font/google"
import { Analytics } from "@vercel/analytics/next"
import "./globals.css"

const _geist = Geist({ subsets: ["latin"] })
const _geistMono = Geist_Mono({ subsets: ["latin"] })
const _vazirmatn = Vazirmatn({ subsets: ["arabic"], weight: ["400", "500", "600", "700"] })

export const metadata: Metadata = {
  title: "کابل آسیا دکوراسیون | داشبورد مدیریت",
  description: "سیستم مدیریت کارگاه نجاری و CNC",
  generator: "v0.app",
}

export const viewport: Viewport = {
  themeColor: "#1a1a2e",
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="fa" dir="rtl" className="dark">
      <body className="font-sans antialiased">
        {children}
        <Analytics />
      </body>
    </html>
  )
}
