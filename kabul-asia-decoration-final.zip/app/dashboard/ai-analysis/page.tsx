"use client"

import { useState } from "react"
import { aiSuggestions } from "@/lib/types"
import { Button } from "@/components/ui/button"
import { Sparkles, RefreshCw, Lightbulb, TrendingUp, Users } from "lucide-react"
import { cn } from "@/lib/utils"

const suggestionIcons = [TrendingUp, Lightbulb, Users]

export default function AIAnalysisPage() {
  const [isLoading, setIsLoading] = useState(false)
  const [suggestions, setSuggestions] = useState<string[]>([])

  const generateAnalysis = () => {
    setIsLoading(true)
    setSuggestions([])

    // Simulate AI analysis with loading animation
    setTimeout(() => {
      setIsLoading(false)
      setSuggestions(aiSuggestions)
    }, 2000)
  }

  return (
    <div className="space-y-8">
      {/* Page Header */}
      <div>
        <h1 className="text-2xl font-bold text-foreground">تحلیل‌گر هوشمند کسب و کار</h1>
        <p className="text-muted-foreground mt-1">دستیار هوش مصنوعی برای تحلیل داده‌ها و ارائه پیشنهادات</p>
      </div>

      {/* AI Card */}
      <div className="glass-card p-8 bg-gradient-to-br from-primary/20 via-primary/10 to-transparent border-primary/30">
        <div className="flex flex-col items-center text-center space-y-6">
          <div
            className={cn(
              "w-20 h-20 rounded-2xl bg-primary/20 flex items-center justify-center",
              isLoading && "animate-pulse",
            )}
          >
            <Sparkles className={cn("w-10 h-10 text-primary", isLoading && "animate-spin")} />
          </div>

          <div>
            <h2 className="text-xl font-bold text-foreground">تحلیل هوشمند داده‌ها</h2>
            <p className="text-muted-foreground mt-2 max-w-md">
              با کلیک روی دکمه زیر، هوش مصنوعی داده‌های کسب و کار شما را تحلیل کرده و پیشنهادات کاربردی ارائه می‌دهد.
            </p>
          </div>

          <Button
            onClick={generateAnalysis}
            disabled={isLoading}
            className="bg-primary text-primary-foreground hover:bg-primary/90 px-8"
          >
            {isLoading ? (
              <>
                <RefreshCw className="w-4 h-4 ml-2 animate-spin" />
                در حال تحلیل...
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4 ml-2" />
                شروع تحلیل
              </>
            )}
          </Button>
        </div>
      </div>

      {/* Loading Animation */}
      {isLoading && (
        <div className="space-y-4">
          {[1, 2, 3].map((i) => (
            <div key={i} className="glass-card p-6 animate-pulse" style={{ animationDelay: `${i * 0.2}s` }}>
              <div className="flex items-start gap-4">
                <div className="w-10 h-10 rounded-xl bg-muted" />
                <div className="flex-1 space-y-3">
                  <div className="h-4 bg-muted rounded w-3/4" />
                  <div className="h-4 bg-muted rounded w-1/2" />
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Suggestions */}
      {suggestions.length > 0 && (
        <div className="space-y-4">
          <h3 className="text-lg font-bold text-foreground">پیشنهادات هوش مصنوعی</h3>
          {suggestions.map((suggestion, index) => {
            const Icon = suggestionIcons[index]
            return (
              <div
                key={index}
                className="glass-card p-6 transition-all duration-300 hover:scale-[1.01] animate-in slide-in-from-bottom-4"
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 rounded-xl bg-primary/20 flex items-center justify-center flex-shrink-0">
                    <Icon className="w-5 h-5 text-primary" />
                  </div>
                  <div>
                    <p className="text-foreground leading-relaxed">{suggestion}</p>
                  </div>
                </div>
              </div>
            )
          })}
        </div>
      )}

      {/* Empty State */}
      {!isLoading && suggestions.length === 0 && (
        <div className="glass-card p-12 text-center">
          <Lightbulb className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
          <p className="text-muted-foreground">برای دریافت پیشنهادات، دکمه "شروع تحلیل" را کلیک کنید.</p>
        </div>
      )}
    </div>
  )
}
