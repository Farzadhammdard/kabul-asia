"use client"

import { useState, useEffect } from "react"
import { createClient } from "@/lib/supabase/client"
import { useAuth } from "@/lib/auth-context"
import { StatCard } from "@/components/stat-card"
import { DataTable } from "@/components/data-table"
import { InvoiceModal } from "@/components/invoice-modal"
import { Button } from "@/components/ui/button"
import { TrendingUp, TrendingDown, DollarSign, Percent, Plus } from "lucide-react"
import {
  type Invoice,
  type Expense,
  type Employee,
  formatNumber,
  serviceTypeLabels,
  calculateAnalytics,
} from "@/lib/types"

export default function DashboardPage() {
  const { user } = useAuth()
  const [invoices, setInvoices] = useState<Invoice[]>([])
  const [expenses, setExpenses] = useState<Expense[]>([])
  const [employees, setEmployees] = useState<Employee[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [modalOpen, setModalOpen] = useState(false)
  const [editingInvoice, setEditingInvoice] = useState<Invoice | undefined>()

  useEffect(() => {
    const fetchData = async () => {
      if (!user) return

      const supabase = createClient()

      const [invoicesRes, expensesRes, employeesRes] = await Promise.all([
        supabase.from("invoices").select("*").order("created_at", { ascending: false }),
        supabase.from("expenses").select("*").order("created_at", { ascending: false }),
        supabase.from("employees").select("*").order("created_at", { ascending: false }),
      ])

      if (invoicesRes.data) setInvoices(invoicesRes.data)
      if (expensesRes.data) setExpenses(expensesRes.data)
      if (employeesRes.data) setEmployees(employeesRes.data)

      setIsLoading(false)
    }

    fetchData()
  }, [user])

  const analytics = calculateAnalytics(invoices, expenses, employees)

  const handleSaveInvoice = async (data: Omit<Invoice, "id" | "total" | "user_id" | "created_at">) => {
    if (!user) return

    const supabase = createClient()
    const total = data.area * data.unit_price - data.discount

    if (editingInvoice) {
      const { data: updated } = await supabase
        .from("invoices")
        .update({ ...data, total })
        .eq("id", editingInvoice.id)
        .select()
        .single()

      if (updated) {
        setInvoices((prev) => prev.map((inv) => (inv.id === editingInvoice.id ? updated : inv)))
      }
    } else {
      const { data: newInvoice } = await supabase
        .from("invoices")
        .insert({ ...data, total, user_id: user.id })
        .select()
        .single()

      if (newInvoice) {
        setInvoices((prev) => [newInvoice, ...prev])
      }
    }

    setEditingInvoice(undefined)
    setModalOpen(false)
  }

  const handleEditInvoice = (invoice: Invoice) => {
    setEditingInvoice(invoice)
    setModalOpen(true)
  }

  const handleDeleteInvoice = async (invoice: Invoice) => {
    const supabase = createClient()
    await supabase.from("invoices").delete().eq("id", invoice.id)
    setInvoices((prev) => prev.filter((inv) => inv.id !== invoice.id))
  }

  const columns = [
    { key: "customer_name", header: "مشتری" },
    { key: "project_name", header: "پروژه" },
    {
      key: "service_type",
      header: "خدمات",
      render: (item: Invoice) => (
        <span className="px-2 py-1 rounded-lg bg-primary/20 text-primary text-xs">
          {serviceTypeLabels[item.service_type]}
        </span>
      ),
    },
    { key: "date", header: "تاریخ" },
    {
      key: "total",
      header: "مبلغ",
      render: (item: Invoice) => <span className="font-medium">{formatNumber(item.total)} ؋</span>,
    },
  ]

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    )
  }

  return (
    <div className="space-y-8">
      {/* Page Header */}
      <div>
        <h1 className="text-2xl font-bold text-foreground">داشبورد</h1>
        <p className="text-muted-foreground mt-1">خلاصه وضعیت کسب و کار</p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6">
        <StatCard
          title="درآمد کل"
          value={`${formatNumber(analytics.totalRevenue)} ؋`}
          icon={TrendingUp}
          variant="success"
          trend="up"
          trendValue="۱۲٪ نسبت به ماه قبل"
        />
        <StatCard
          title="هزینه‌ها"
          value={`${formatNumber(analytics.totalExpenses)} ؋`}
          subtitle="شامل حقوق و مخارج"
          icon={TrendingDown}
          variant="warning"
        />
        <StatCard
          title="سود خالص"
          value={`${formatNumber(analytics.netProfit)} ؋`}
          icon={DollarSign}
          variant={analytics.netProfit >= 0 ? "success" : "danger"}
        />
        <StatCard title="حاشیه سود" value={`${analytics.profitMargin.toFixed(1)}٪`} icon={Percent} variant="default" />
      </div>

      {/* Recent Invoices */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-xl font-bold text-foreground">فاکتورهای اخیر</h2>
          <Button
            onClick={() => {
              setEditingInvoice(undefined)
              setModalOpen(true)
            }}
            className="bg-primary text-primary-foreground hover:bg-primary/90"
          >
            <Plus className="w-4 h-4 ml-2" />
            فاکتور جدید
          </Button>
        </div>
        <DataTable
          data={invoices.slice(0, 5)}
          columns={columns}
          onEdit={handleEditInvoice}
          onDelete={handleDeleteInvoice}
          emptyMessage="فاکتوری ثبت نشده است"
        />
      </div>

      <InvoiceModal
        open={modalOpen}
        onClose={() => {
          setModalOpen(false)
          setEditingInvoice(undefined)
        }}
        onSave={handleSaveInvoice}
        invoice={editingInvoice}
      />
    </div>
  )
}
