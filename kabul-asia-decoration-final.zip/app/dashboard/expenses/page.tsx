"use client"

import { useState, useEffect } from "react"
import { createClient } from "@/lib/supabase/client"
import { useAuth } from "@/lib/auth-context"
import { type Expense, categoryLabels, formatNumber } from "@/lib/types"
import { DataTable } from "@/components/data-table"
import { ExpenseModal } from "@/components/expense-modal"
import { StatCard } from "@/components/stat-card"
import { Button } from "@/components/ui/button"
import { Plus, Package, Zap, FolderOpen } from "lucide-react"

const categoryIcons = {
  Materials: Package,
  "Rent & Electricity": Zap,
  General: FolderOpen,
}

export default function ExpensesPage() {
  const { user } = useAuth()
  const [expenses, setExpenses] = useState<Expense[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [modalOpen, setModalOpen] = useState(false)
  const [editingExpense, setEditingExpense] = useState<Expense | undefined>()

  useEffect(() => {
    const fetchExpenses = async () => {
      if (!user) return

      const supabase = createClient()
      const { data } = await supabase.from("expenses").select("*").order("created_at", { ascending: false })

      if (data) setExpenses(data)
      setIsLoading(false)
    }

    fetchExpenses()
  }, [user])

  const handleSaveExpense = async (data: Omit<Expense, "id" | "user_id" | "created_at">) => {
    if (!user) return

    const supabase = createClient()

    if (editingExpense) {
      const { data: updated } = await supabase
        .from("expenses")
        .update(data)
        .eq("id", editingExpense.id)
        .select()
        .single()

      if (updated) {
        setExpenses((prev) => prev.map((exp) => (exp.id === editingExpense.id ? updated : exp)))
      }
    } else {
      const { data: newExpense } = await supabase
        .from("expenses")
        .insert({ ...data, user_id: user.id })
        .select()
        .single()

      if (newExpense) {
        setExpenses((prev) => [newExpense, ...prev])
      }
    }

    setEditingExpense(undefined)
    setModalOpen(false)
  }

  const handleDeleteExpense = async (expense: Expense) => {
    const supabase = createClient()
    await supabase.from("expenses").delete().eq("id", expense.id)
    setExpenses((prev) => prev.filter((exp) => exp.id !== expense.id))
  }

  // Calculate totals by category
  const categoryTotals = expenses.reduce(
    (acc, exp) => {
      acc[exp.category] = (acc[exp.category] || 0) + exp.amount
      return acc
    },
    {} as Record<string, number>,
  )

  const totalExpenses = expenses.reduce((sum, exp) => sum + exp.amount, 0)

  const columns = [
    { key: "title", header: "عنوان" },
    {
      key: "category",
      header: "دسته‌بندی",
      render: (item: Expense) => {
        const Icon = categoryIcons[item.category]
        return (
          <div className="flex items-center gap-2">
            <Icon className="w-4 h-4 text-warning" />
            <span>{categoryLabels[item.category]}</span>
          </div>
        )
      },
    },
    {
      key: "amount",
      header: "مبلغ",
      render: (item: Expense) => <span className="font-medium text-warning">{formatNumber(item.amount)} ؋</span>,
    },
    { key: "date", header: "تاریخ" },
  ]

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    )
  }

  return (
    <div className="space-y-8">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-foreground">مدیریت هزینه‌ها</h1>
          <p className="text-muted-foreground mt-1">ثبت و پیگیری مخارج کارگاه</p>
        </div>
        <Button
          onClick={() => {
            setEditingExpense(undefined)
            setModalOpen(true)
          }}
          className="bg-primary text-primary-foreground hover:bg-primary/90"
        >
          <Plus className="w-4 h-4 ml-2" />
          هزینه جدید
        </Button>
      </div>

      {/* Category Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <StatCard
          title="مواد اولیه"
          value={`${formatNumber(categoryTotals["Materials"] || 0)} ؋`}
          icon={Package}
          variant="warning"
        />
        <StatCard
          title="اجاره و برق"
          value={`${formatNumber(categoryTotals["Rent & Electricity"] || 0)} ؋`}
          icon={Zap}
          variant="warning"
        />
        <StatCard
          title="عمومی"
          value={`${formatNumber(categoryTotals["General"] || 0)} ؋`}
          icon={FolderOpen}
          variant="warning"
        />
      </div>

      {/* Total Summary */}
      <div className="glass-card p-6 bg-gradient-to-br from-warning/20 to-warning/5 border-warning/20">
        <div className="flex items-center justify-between">
          <span className="text-muted-foreground">جمع کل هزینه‌ها:</span>
          <span className="text-3xl font-bold text-warning">{formatNumber(totalExpenses)} ؋</span>
        </div>
      </div>

      {/* Data Table */}
      <DataTable
        data={expenses}
        columns={columns}
        onEdit={(expense) => {
          setEditingExpense(expense)
          setModalOpen(true)
        }}
        onDelete={handleDeleteExpense}
        emptyMessage="هزینه‌ای ثبت نشده است"
      />

      <ExpenseModal
        open={modalOpen}
        onClose={() => {
          setModalOpen(false)
          setEditingExpense(undefined)
        }}
        onSave={handleSaveExpense}
        expense={editingExpense}
      />
    </div>
  )
}
