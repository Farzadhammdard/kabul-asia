import type React from "react"
import { AuthProvider } from "@/lib/auth-context"
import { Sidebar } from "@/components/sidebar"
import { DashboardGuard } from "@/components/dashboard-guard"

export default function DashboardLayout({
  children,
}: {
  children: React.ReactNode
}) {
  // Auth is now handled entirely on the client side in DashboardGuard
  return (
    <AuthProvider>
      <DashboardGuard>
        <div className="min-h-screen">
          <Sidebar />
          <main className="lg:pr-72 pt-16 lg:pt-0">
            <div className="p-6 lg:p-8">{children}</div>
          </main>
        </div>
      </DashboardGuard>
    </AuthProvider>
  )
}
