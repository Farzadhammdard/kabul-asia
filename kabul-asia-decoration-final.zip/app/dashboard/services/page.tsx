"use client"

import { useState, useEffect } from "react"
import { createClient } from "@/lib/supabase/client"
import { useAuth } from "@/lib/auth-context"
import { type Invoice, serviceTypeLabels, formatNumber } from "@/lib/types"
import { DataTable } from "@/components/data-table"
import { InvoiceModal } from "@/components/invoice-modal"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"
import { Plus, Layers, Box, Scissors, Hammer } from "lucide-react"

const serviceIcons = {
  CNC: Layers,
  PVC: Box,
  Cutting: Scissors,
  Carpentry: Hammer,
}

type ServiceFilter = "all" | Invoice["service_type"]

export default function ServicesPage() {
  const { user } = useAuth()
  const [invoices, setInvoices] = useState<Invoice[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [filter, setFilter] = useState<ServiceFilter>("all")
  const [modalOpen, setModalOpen] = useState(false)
  const [editingInvoice, setEditingInvoice] = useState<Invoice | undefined>()

  useEffect(() => {
    const fetchInvoices = async () => {
      if (!user) return

      const supabase = createClient()
      const { data } = await supabase.from("invoices").select("*").order("created_at", { ascending: false })

      if (data) setInvoices(data)
      setIsLoading(false)
    }

    fetchInvoices()
  }, [user])

  const filteredInvoices = filter === "all" ? invoices : invoices.filter((inv) => inv.service_type === filter)

  const handleSaveInvoice = async (data: Omit<Invoice, "id" | "total" | "user_id" | "created_at">) => {
    if (!user) return

    const supabase = createClient()
    const total = data.area * data.unit_price - data.discount

    if (editingInvoice) {
      const { data: updated } = await supabase
        .from("invoices")
        .update({ ...data, total })
        .eq("id", editingInvoice.id)
        .select()
        .single()

      if (updated) {
        setInvoices((prev) => prev.map((inv) => (inv.id === editingInvoice.id ? updated : inv)))
      }
    } else {
      const { data: newInvoice } = await supabase
        .from("invoices")
        .insert({ ...data, total, user_id: user.id })
        .select()
        .single()

      if (newInvoice) {
        setInvoices((prev) => [newInvoice, ...prev])
      }
    }

    setEditingInvoice(undefined)
    setModalOpen(false)
  }

  const handleDeleteInvoice = async (invoice: Invoice) => {
    const supabase = createClient()
    await supabase.from("invoices").delete().eq("id", invoice.id)
    setInvoices((prev) => prev.filter((inv) => inv.id !== invoice.id))
  }

  const filterTabs: { key: ServiceFilter; label: string; icon?: typeof Layers }[] = [
    { key: "all", label: "همه" },
    { key: "CNC", label: "CNC", icon: Layers },
    { key: "PVC", label: "PVC", icon: Box },
    { key: "Cutting", label: "برش", icon: Scissors },
    { key: "Carpentry", label: "نجاری", icon: Hammer },
  ]

  const columns = [
    { key: "customer_name", header: "مشتری" },
    { key: "project_name", header: "پروژه" },
    {
      key: "service_type",
      header: "نوع خدمات",
      render: (item: Invoice) => {
        const Icon = serviceIcons[item.service_type]
        return (
          <div className="flex items-center gap-2">
            <Icon className="w-4 h-4 text-primary" />
            <span>{serviceTypeLabels[item.service_type]}</span>
          </div>
        )
      },
    },
    {
      key: "area",
      header: "مساحت/تعداد",
      render: (item: Invoice) => <span>{formatNumber(item.area)}</span>,
    },
    {
      key: "unit_price",
      header: "قیمت واحد",
      render: (item: Invoice) => <span>{formatNumber(item.unit_price)} ؋</span>,
    },
    {
      key: "discount",
      header: "تخفیف",
      render: (item: Invoice) => <span>{formatNumber(item.discount)} ؋</span>,
    },
    {
      key: "total",
      header: "جمع کل",
      render: (item: Invoice) => <span className="font-bold text-primary">{formatNumber(item.total)} ؋</span>,
    },
    { key: "date", header: "تاریخ" },
  ]

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    )
  }

  return (
    <div className="space-y-8">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-foreground">مدیریت خدمات</h1>
          <p className="text-muted-foreground mt-1">فاکتورها بر اساس نوع خدمات</p>
        </div>
        <Button
          onClick={() => {
            setEditingInvoice(undefined)
            setModalOpen(true)
          }}
          className="bg-primary text-primary-foreground hover:bg-primary/90"
        >
          <Plus className="w-4 h-4 ml-2" />
          فاکتور جدید
        </Button>
      </div>

      {/* Filter Tabs */}
      <div className="flex flex-wrap gap-2">
        {filterTabs.map((tab) => (
          <button
            key={tab.key}
            onClick={() => setFilter(tab.key)}
            className={cn(
              "flex items-center gap-2 px-4 py-2 rounded-xl transition-all duration-200",
              filter === tab.key
                ? "bg-primary text-primary-foreground"
                : "glass-card text-muted-foreground hover:text-foreground",
            )}
          >
            {tab.icon && <tab.icon className="w-4 h-4" />}
            <span>{tab.label}</span>
            <span className="text-xs opacity-70">
              ({tab.key === "all" ? invoices.length : invoices.filter((i) => i.service_type === tab.key).length})
            </span>
          </button>
        ))}
      </div>

      {/* Data Table */}
      <DataTable
        data={filteredInvoices}
        columns={columns}
        onEdit={(invoice) => {
          setEditingInvoice(invoice)
          setModalOpen(true)
        }}
        onDelete={handleDeleteInvoice}
        emptyMessage="فاکتوری برای این نوع خدمات یافت نشد"
      />

      <InvoiceModal
        open={modalOpen}
        onClose={() => {
          setModalOpen(false)
          setEditingInvoice(undefined)
        }}
        onSave={handleSaveInvoice}
        invoice={editingInvoice}
      />
    </div>
  )
}
