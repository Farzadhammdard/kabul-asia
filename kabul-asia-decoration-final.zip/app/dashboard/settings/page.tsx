"use client"

import type React from "react"

import { useState, useEffect, useRef } from "react"
import { createClient } from "@/lib/supabase/client"
import { useAuth } from "@/lib/auth-context"
import type { Profile } from "@/lib/types"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Plus, Users, Settings, Shield, Bell, Lock, Trash2, Edit, Key, Building } from "lucide-react"

export default function SettingsPage() {
  const { isAdmin, profile, user, refreshProfile } = useAuth()
  const [users, setUsers] = useState<Profile[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [modalOpen, setModalOpen] = useState(false)
  const [passwordModalOpen, setPasswordModalOpen] = useState(false)
  const [editModalOpen, setEditModalOpen] = useState(false)
  const [notifications, setNotifications] = useState(true)
  const [autoBackup, setAutoBackup] = useState(true)
  const mountedRef = useRef(true)

  // Workshop info state
  const [workshopName, setWorkshopName] = useState("کابل آسیا دکوراسیون")
  const [workshopPhone, setWorkshopPhone] = useState("+93 70 123 4567")
  const [workshopAddress, setWorkshopAddress] = useState("کابل، افغانستان")

  // New user state
  const [newUser, setNewUser] = useState({
    name: "",
    email: "",
    password: "",
    role: "Operator" as "Admin" | "Operator",
  })
  const [signupError, setSignupError] = useState("")
  const [signupSuccess, setSignupSuccess] = useState("")
  const [isCreating, setIsCreating] = useState(false)

  // Password change state
  const [currentPassword, setCurrentPassword] = useState("")
  const [newPassword, setNewPassword] = useState("")
  const [confirmPassword, setConfirmPassword] = useState("")
  const [passwordError, setPasswordError] = useState("")
  const [passwordSuccess, setPasswordSuccess] = useState("")
  const [isChangingPassword, setIsChangingPassword] = useState(false)

  // Edit user state
  const [editingUser, setEditingUser] = useState<Profile | null>(null)
  const [editName, setEditName] = useState("")
  const [editRole, setEditRole] = useState<"Admin" | "Operator">("Operator")

  useEffect(() => {
    mountedRef.current = true

    const fetchUsers = async () => {
      if (!isAdmin) {
        setIsLoading(false)
        return
      }

      try {
        const supabase = createClient()
        const { data, error } = await supabase.from("profiles").select("*").order("created_at", { ascending: false })

        if (!mountedRef.current) return

        if (error) {
          console.error("Error fetching users:", error)
          if (profile) {
            setUsers([profile])
          }
        } else {
          setUsers(data || [])
        }
      } catch (error) {
        if (error instanceof Error && error.name === "AbortError") return
        console.error("Error:", error)
        if (mountedRef.current && profile) {
          setUsers([profile])
        }
      } finally {
        if (mountedRef.current) {
          setIsLoading(false)
        }
      }
    }

    fetchUsers()

    return () => {
      mountedRef.current = false
    }
  }, [isAdmin, profile])

  const handleAddUser = async (e: React.FormEvent) => {
    e.preventDefault()
    setSignupError("")
    setSignupSuccess("")
    setIsCreating(true)

    const supabase = createClient()

    try {
      const { error } = await supabase.auth.signUp({
        email: newUser.email,
        password: newUser.password,
        options: {
          emailRedirectTo: process.env.NEXT_PUBLIC_DEV_SUPABASE_REDIRECT_URL || `${window.location.origin}/dashboard`,
          data: {
            name: newUser.name,
            role: newUser.role,
          },
        },
      })

      if (error) throw error

      setSignupSuccess("کاربر جدید ایجاد شد. ایمیل تایید ارسال شد.")
      setModalOpen(false)
      setNewUser({ name: "", email: "", password: "", role: "Operator" })

      // Refresh users list
      const { data } = await supabase.from("profiles").select("*").order("created_at", { ascending: false })
      if (data) setUsers(data)
    } catch (err) {
      setSignupError(err instanceof Error ? err.message : "خطایی رخ داد")
    } finally {
      setIsCreating(false)
    }
  }

  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault()
    setPasswordError("")
    setPasswordSuccess("")

    if (newPassword !== confirmPassword) {
      setPasswordError("رمز عبور جدید و تکرار آن مطابقت ندارند")
      return
    }

    if (newPassword.length < 6) {
      setPasswordError("رمز عبور باید حداقل ۶ کاراکتر باشد")
      return
    }

    setIsChangingPassword(true)
    const supabase = createClient()

    try {
      const { error } = await supabase.auth.updateUser({
        password: newPassword,
      })

      if (error) throw error

      setPasswordSuccess("رمز عبور با موفقیت تغییر کرد")
      setCurrentPassword("")
      setNewPassword("")
      setConfirmPassword("")
      setPasswordModalOpen(false)
    } catch (err) {
      setPasswordError(err instanceof Error ? err.message : "خطایی رخ داد")
    } finally {
      setIsChangingPassword(false)
    }
  }

  const handleEditUser = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!editingUser) return

    const supabase = createClient()

    try {
      const { error } = await supabase
        .from("profiles")
        .update({ name: editName, role: editRole })
        .eq("id", editingUser.id)

      if (error) throw error

      // Refresh users list
      const { data } = await supabase.from("profiles").select("*").order("created_at", { ascending: false })
      if (data) setUsers(data)

      setEditModalOpen(false)
      setEditingUser(null)

      // Refresh current user profile if editing self
      if (editingUser.id === user?.id) {
        await refreshProfile()
      }
    } catch (err) {
      console.error("Error updating user:", err)
    }
  }

  const handleDeleteUser = async (userId: string) => {
    if (userId === user?.id) {
      alert("شما نمی‌توانید حساب خود را حذف کنید")
      return
    }

    if (!confirm("آیا از حذف این کاربر اطمینان دارید؟")) return

    const supabase = createClient()

    try {
      const { error } = await supabase.from("profiles").delete().eq("id", userId)

      if (error) throw error

      setUsers((prev) => prev.filter((u) => u.id !== userId))
    } catch (err) {
      console.error("Error deleting user:", err)
    }
  }

  const openEditModal = (userToEdit: Profile) => {
    setEditingUser(userToEdit)
    setEditName(userToEdit.name)
    setEditRole(userToEdit.role)
    setEditModalOpen(true)
  }

  if (!isAdmin) {
    return (
      <div className="space-y-8">
        <div>
          <h1 className="text-2xl font-bold text-foreground">تنظیمات</h1>
          <p className="text-muted-foreground mt-1">تنظیمات حساب کاربری</p>
        </div>

        {/* Password Change for Operators */}
        <div className="glass-card p-6 space-y-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-primary/20 flex items-center justify-center">
              <Key className="w-5 h-5 text-primary" />
            </div>
            <h3 className="text-lg font-bold text-foreground">تغییر رمز عبور</h3>
          </div>

          <form onSubmit={handleChangePassword} className="space-y-4 max-w-md">
            <div className="space-y-2">
              <Label className="text-muted-foreground">رمز عبور جدید</Label>
              <Input
                type="password"
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                className="bg-input border-border/50"
                required
                minLength={6}
              />
            </div>
            <div className="space-y-2">
              <Label className="text-muted-foreground">تکرار رمز عبور جدید</Label>
              <Input
                type="password"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                className="bg-input border-border/50"
                required
                minLength={6}
              />
            </div>

            {passwordError && <p className="text-destructive text-sm">{passwordError}</p>}
            {passwordSuccess && <p className="text-green-500 text-sm">{passwordSuccess}</p>}

            <Button
              type="submit"
              className="bg-primary text-primary-foreground hover:bg-primary/90"
              disabled={isChangingPassword}
            >
              {isChangingPassword ? "در حال تغییر..." : "تغییر رمز عبور"}
            </Button>
          </form>
        </div>

        {/* User Info */}
        <div className="glass-card p-6 space-y-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-muted/50 flex items-center justify-center">
              <Shield className="w-5 h-5 text-muted-foreground" />
            </div>
            <h3 className="text-lg font-bold text-foreground">اطلاعات حساب</h3>
          </div>

          <div className="space-y-3">
            <div className="flex justify-between">
              <span className="text-muted-foreground">نام:</span>
              <span className="text-foreground">{profile?.name}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">ایمیل:</span>
              <span className="text-foreground">{profile?.email}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">نقش:</span>
              <span className="text-foreground">اپراتور</span>
            </div>
          </div>
        </div>
      </div>
    )
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    )
  }

  return (
    <div className="space-y-8">
      {/* Page Header */}
      <div>
        <h1 className="text-2xl font-bold text-foreground">تنظیمات سیستم</h1>
        <p className="text-muted-foreground mt-1">مدیریت کاربران، رمز عبور و تنظیمات</p>
      </div>

      {signupSuccess && (
        <div className="glass-card p-4 bg-green-500/10 border-green-500/30 text-green-400">{signupSuccess}</div>
      )}
      {passwordSuccess && (
        <div className="glass-card p-4 bg-green-500/10 border-green-500/30 text-green-400">{passwordSuccess}</div>
      )}

      <Tabs defaultValue="users" className="space-y-6">
        <TabsList className="glass-card p-1">
          <TabsTrigger
            value="users"
            className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
          >
            <Users className="w-4 h-4 ml-2" />
            کاربران
          </TabsTrigger>
          <TabsTrigger
            value="security"
            className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
          >
            <Lock className="w-4 h-4 ml-2" />
            امنیت
          </TabsTrigger>
          <TabsTrigger
            value="workshop"
            className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
          >
            <Building className="w-4 h-4 ml-2" />
            کارگاه
          </TabsTrigger>
          <TabsTrigger
            value="general"
            className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
          >
            <Settings className="w-4 h-4 ml-2" />
            عمومی
          </TabsTrigger>
        </TabsList>

        {/* Users Tab */}
        <TabsContent value="users" className="space-y-6">
          <div className="glass-card p-6 space-y-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-primary/20 flex items-center justify-center">
                  <Users className="w-5 h-5 text-primary" />
                </div>
                <div>
                  <h3 className="text-lg font-bold text-foreground">مدیریت کاربران</h3>
                  <p className="text-sm text-muted-foreground">{users.length} کاربر</p>
                </div>
              </div>
              <Button
                onClick={() => setModalOpen(true)}
                className="bg-primary text-primary-foreground hover:bg-primary/90"
              >
                <Plus className="w-4 h-4 ml-2" />
                کاربر جدید
              </Button>
            </div>

            <div className="space-y-3">
              {users.map((userItem) => (
                <div key={userItem.id} className="flex items-center justify-between p-4 rounded-xl bg-muted/30">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center">
                      <span className="text-primary font-bold">{userItem.name[0]}</span>
                    </div>
                    <div>
                      <p className="font-medium text-foreground">{userItem.name}</p>
                      <p className="text-sm text-muted-foreground">{userItem.email}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <span
                      className={`px-3 py-1 rounded-lg text-xs ${
                        userItem.role === "Admin" ? "bg-primary/20 text-primary" : "bg-muted text-muted-foreground"
                      }`}
                    >
                      {userItem.role === "Admin" ? "مدیر" : "اپراتور"}
                    </span>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => openEditModal(userItem)}
                      className="text-muted-foreground hover:text-foreground"
                    >
                      <Edit className="w-4 h-4" />
                    </Button>
                    {userItem.id !== user?.id && (
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => handleDeleteUser(userItem.id)}
                        className="text-destructive hover:text-destructive/80"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </TabsContent>

        {/* Security Tab */}
        <TabsContent value="security" className="space-y-6">
          <div className="glass-card p-6 space-y-6">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-warning/20 flex items-center justify-center">
                <Key className="w-5 h-5 text-warning" />
              </div>
              <h3 className="text-lg font-bold text-foreground">تغییر رمز عبور</h3>
            </div>

            <form onSubmit={handleChangePassword} className="space-y-4 max-w-md">
              <div className="space-y-2">
                <Label className="text-muted-foreground">رمز عبور جدید</Label>
                <Input
                  type="password"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  className="bg-input border-border/50"
                  required
                  minLength={6}
                />
              </div>
              <div className="space-y-2">
                <Label className="text-muted-foreground">تکرار رمز عبور جدید</Label>
                <Input
                  type="password"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  className="bg-input border-border/50"
                  required
                  minLength={6}
                />
                <p className="text-xs text-muted-foreground">حداقل ۶ کاراکتر</p>
              </div>

              {passwordError && <p className="text-destructive text-sm">{passwordError}</p>}

              <Button
                type="submit"
                className="bg-primary text-primary-foreground hover:bg-primary/90"
                disabled={isChangingPassword}
              >
                {isChangingPassword ? "در حال تغییر..." : "تغییر رمز عبور"}
              </Button>
            </form>
          </div>
        </TabsContent>

        {/* Workshop Tab */}
        <TabsContent value="workshop" className="space-y-6">
          <div className="glass-card p-6 space-y-6">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-primary/20 flex items-center justify-center">
                <Building className="w-5 h-5 text-primary" />
              </div>
              <h3 className="text-lg font-bold text-foreground">اطلاعات کارگاه</h3>
            </div>

            <div className="space-y-4 max-w-md">
              <div className="space-y-2">
                <Label className="text-muted-foreground">نام کارگاه</Label>
                <Input
                  value={workshopName}
                  onChange={(e) => setWorkshopName(e.target.value)}
                  className="bg-input border-border/50"
                />
              </div>
              <div className="space-y-2">
                <Label className="text-muted-foreground">شماره تماس</Label>
                <Input
                  value={workshopPhone}
                  onChange={(e) => setWorkshopPhone(e.target.value)}
                  className="bg-input border-border/50"
                />
              </div>
              <div className="space-y-2">
                <Label className="text-muted-foreground">آدرس</Label>
                <Input
                  value={workshopAddress}
                  onChange={(e) => setWorkshopAddress(e.target.value)}
                  className="bg-input border-border/50"
                />
              </div>

              <Button className="bg-primary text-primary-foreground hover:bg-primary/90">ذخیره تغییرات</Button>
            </div>
          </div>
        </TabsContent>

        {/* General Tab */}
        <TabsContent value="general" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="glass-card p-6 space-y-6">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-primary/20 flex items-center justify-center">
                  <Settings className="w-5 h-5 text-primary" />
                </div>
                <h3 className="text-lg font-bold text-foreground">تنظیمات عمومی</h3>
              </div>

              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-medium text-foreground">اعلان‌ها</p>
                    <p className="text-sm text-muted-foreground">دریافت اعلان برای فاکتورهای جدید</p>
                  </div>
                  <Switch checked={notifications} onCheckedChange={setNotifications} />
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-medium text-foreground">پشتیبان‌گیری خودکار</p>
                    <p className="text-sm text-muted-foreground">ذخیره خودکار داده‌ها هر ۲۴ ساعت</p>
                  </div>
                  <Switch checked={autoBackup} onCheckedChange={setAutoBackup} />
                </div>
              </div>
            </div>

            <div className="glass-card p-6 space-y-6">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-warning/20 flex items-center justify-center">
                  <Bell className="w-5 h-5 text-warning" />
                </div>
                <h3 className="text-lg font-bold text-foreground">اطلاعات سیستم</h3>
              </div>

              <div className="space-y-3 text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">نسخه:</span>
                  <span className="text-foreground">1.0.0</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">آخرین بروزرسانی:</span>
                  <span className="text-foreground">۱۴۰۴/۱۰/۲۲</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">دیتابیس:</span>
                  <span className="text-green-500">متصل</span>
                </div>
              </div>
            </div>
          </div>
        </TabsContent>
      </Tabs>

      {/* Add User Modal */}
      <Dialog open={modalOpen} onOpenChange={setModalOpen}>
        <DialogContent className="glass-card border-border/50 max-w-md">
          <DialogHeader>
            <DialogTitle className="text-foreground">افزودن کاربر جدید</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleAddUser} className="space-y-4">
            <div className="space-y-2">
              <Label className="text-muted-foreground">نام</Label>
              <Input
                value={newUser.name}
                onChange={(e) => setNewUser((prev) => ({ ...prev, name: e.target.value }))}
                className="bg-input border-border/50"
                required
              />
            </div>
            <div className="space-y-2">
              <Label className="text-muted-foreground">ایمیل</Label>
              <Input
                type="email"
                value={newUser.email}
                onChange={(e) => setNewUser((prev) => ({ ...prev, email: e.target.value }))}
                className="bg-input border-border/50"
                required
              />
            </div>
            <div className="space-y-2">
              <Label className="text-muted-foreground">رمز عبور</Label>
              <Input
                type="password"
                value={newUser.password}
                onChange={(e) => setNewUser((prev) => ({ ...prev, password: e.target.value }))}
                className="bg-input border-border/50"
                required
                minLength={6}
              />
              <p className="text-xs text-muted-foreground">حداقل ۶ کاراکتر</p>
            </div>
            <div className="space-y-2">
              <Label className="text-muted-foreground">نقش</Label>
              <div className="flex gap-3">
                <Button
                  type="button"
                  variant={newUser.role === "Operator" ? "default" : "outline"}
                  onClick={() => setNewUser((prev) => ({ ...prev, role: "Operator" }))}
                  className={newUser.role === "Operator" ? "bg-primary text-primary-foreground" : "border-border/50"}
                >
                  اپراتور
                </Button>
                <Button
                  type="button"
                  variant={newUser.role === "Admin" ? "default" : "outline"}
                  onClick={() => setNewUser((prev) => ({ ...prev, role: "Admin" }))}
                  className={newUser.role === "Admin" ? "bg-primary text-primary-foreground" : "border-border/50"}
                >
                  مدیر
                </Button>
              </div>
            </div>

            {signupError && <p className="text-destructive text-sm">{signupError}</p>}

            <div className="flex gap-3 pt-4">
              <Button
                type="submit"
                className="flex-1 bg-primary text-primary-foreground hover:bg-primary/90"
                disabled={isCreating}
              >
                {isCreating ? "در حال ایجاد..." : "افزودن کاربر"}
              </Button>
              <Button type="button" variant="outline" onClick={() => setModalOpen(false)} className="border-border/50">
                انصراف
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>

      {/* Edit User Modal */}
      <Dialog open={editModalOpen} onOpenChange={setEditModalOpen}>
        <DialogContent className="glass-card border-border/50 max-w-md">
          <DialogHeader>
            <DialogTitle className="text-foreground">ویرایش کاربر</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleEditUser} className="space-y-4">
            <div className="space-y-2">
              <Label className="text-muted-foreground">نام</Label>
              <Input
                value={editName}
                onChange={(e) => setEditName(e.target.value)}
                className="bg-input border-border/50"
                required
              />
            </div>
            <div className="space-y-2">
              <Label className="text-muted-foreground">نقش</Label>
              <div className="flex gap-3">
                <Button
                  type="button"
                  variant={editRole === "Operator" ? "default" : "outline"}
                  onClick={() => setEditRole("Operator")}
                  className={editRole === "Operator" ? "bg-primary text-primary-foreground" : "border-border/50"}
                >
                  اپراتور
                </Button>
                <Button
                  type="button"
                  variant={editRole === "Admin" ? "default" : "outline"}
                  onClick={() => setEditRole("Admin")}
                  className={editRole === "Admin" ? "bg-primary text-primary-foreground" : "border-border/50"}
                >
                  مدیر
                </Button>
              </div>
            </div>

            <div className="flex gap-3 pt-4">
              <Button type="submit" className="flex-1 bg-primary text-primary-foreground hover:bg-primary/90">
                ذخیره تغییرات
              </Button>
              <Button
                type="button"
                variant="outline"
                onClick={() => setEditModalOpen(false)}
                className="border-border/50"
              >
                انصراف
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  )
}
