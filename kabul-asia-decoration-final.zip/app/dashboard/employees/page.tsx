"use client"

import { useState, useEffect } from "react"
import { createClient } from "@/lib/supabase/client"
import { useAuth } from "@/lib/auth-context"
import { type Employee, formatNumber } from "@/lib/types"
import { DataTable } from "@/components/data-table"
import { EmployeeModal } from "@/components/employee-modal"
import { StatCard } from "@/components/stat-card"
import { Button } from "@/components/ui/button"
import { Plus, Users, Calendar, Banknote } from "lucide-react"

export default function EmployeesPage() {
  const { user } = useAuth()
  const [employees, setEmployees] = useState<Employee[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [modalOpen, setModalOpen] = useState(false)
  const [editingEmployee, setEditingEmployee] = useState<Employee | undefined>()

  useEffect(() => {
    const fetchEmployees = async () => {
      if (!user) return

      const supabase = createClient()
      const { data } = await supabase.from("employees").select("*").order("created_at", { ascending: false })

      if (data) setEmployees(data)
      setIsLoading(false)
    }

    fetchEmployees()
  }, [user])

  const handleSaveEmployee = async (data: Omit<Employee, "id" | "calculated_salary" | "user_id" | "created_at">) => {
    if (!user) return

    const supabase = createClient()
    const calculated_salary = (data.base_salary / 26) * data.attendance_days

    if (editingEmployee) {
      const { data: updated } = await supabase
        .from("employees")
        .update({ ...data, calculated_salary })
        .eq("id", editingEmployee.id)
        .select()
        .single()

      if (updated) {
        setEmployees((prev) => prev.map((emp) => (emp.id === editingEmployee.id ? updated : emp)))
      }
    } else {
      const { data: newEmployee } = await supabase
        .from("employees")
        .insert({ ...data, calculated_salary, user_id: user.id })
        .select()
        .single()

      if (newEmployee) {
        setEmployees((prev) => [newEmployee, ...prev])
      }
    }

    setEditingEmployee(undefined)
    setModalOpen(false)
  }

  const handleDeleteEmployee = async (employee: Employee) => {
    const supabase = createClient()
    await supabase.from("employees").delete().eq("id", employee.id)
    setEmployees((prev) => prev.filter((emp) => emp.id !== employee.id))
  }

  const totalSalaries = employees.reduce((sum, emp) => sum + emp.calculated_salary, 0)
  const avgAttendance =
    employees.length > 0 ? employees.reduce((sum, emp) => sum + emp.attendance_days, 0) / employees.length : 0

  const columns = [
    { key: "name", header: "نام کارمند" },
    {
      key: "base_salary",
      header: "حقوق پایه",
      render: (item: Employee) => <span>{formatNumber(item.base_salary)} ؋</span>,
    },
    {
      key: "attendance_days",
      header: "روزهای حضور",
      render: (item: Employee) => (
        <div className="flex items-center gap-2">
          <div className="w-full max-w-[100px] h-2 bg-muted rounded-full overflow-hidden">
            <div
              className="h-full bg-primary rounded-full"
              style={{ width: `${(item.attendance_days / 26) * 100}%` }}
            />
          </div>
          <span className="text-sm">{item.attendance_days}/۲۶</span>
        </div>
      ),
    },
    {
      key: "calculated_salary",
      header: "حقوق محاسبه شده",
      render: (item: Employee) => (
        <span className="font-bold text-primary">{formatNumber(item.calculated_salary)} ؋</span>
      ),
    },
  ]

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    )
  }

  return (
    <div className="space-y-8">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-foreground">مدیریت کارکنان</h1>
          <p className="text-muted-foreground mt-1">حقوق و حضور کارمندان</p>
        </div>
        <Button
          onClick={() => {
            setEditingEmployee(undefined)
            setModalOpen(true)
          }}
          className="bg-primary text-primary-foreground hover:bg-primary/90"
        >
          <Plus className="w-4 h-4 ml-2" />
          کارمند جدید
        </Button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <StatCard
          title="تعداد کارکنان"
          value={String(employees.length)}
          subtitle="کارمند فعال"
          icon={Users}
          variant="default"
        />
        <StatCard
          title="میانگین حضور"
          value={`${avgAttendance.toFixed(1)} روز`}
          subtitle="از ۲۶ روز کاری"
          icon={Calendar}
          variant="success"
        />
        <StatCard
          title="جمع حقوق ماهانه"
          value={`${formatNumber(totalSalaries)} ؋`}
          icon={Banknote}
          variant="warning"
        />
      </div>

      {/* Formula Explanation */}
      <div className="glass-card p-6 bg-gradient-to-br from-primary/10 to-primary/5 border-primary/20">
        <h3 className="font-bold text-foreground mb-2">فرمول محاسبه حقوق</h3>
        <p className="text-muted-foreground">حقوق = (حقوق پایه ÷ ۲۶) × روزهای حضور</p>
      </div>

      {/* Data Table */}
      <DataTable
        data={employees}
        columns={columns}
        onEdit={(employee) => {
          setEditingEmployee(employee)
          setModalOpen(true)
        }}
        onDelete={handleDeleteEmployee}
        emptyMessage="کارمندی ثبت نشده است"
      />

      <EmployeeModal
        open={modalOpen}
        onClose={() => {
          setModalOpen(false)
          setEditingEmployee(undefined)
        }}
        onSave={handleSaveEmployee}
        employee={editingEmployee}
      />
    </div>
  )
}
