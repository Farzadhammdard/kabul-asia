"use client"

import type React from "react"

import { cn } from "@/lib/utils"

interface Column<T> {
  key: keyof T | string
  header: string
  render?: (item: T) => React.ReactNode
  className?: string
}

interface DataTableProps<T> {
  data: T[]
  columns: Column<T>[]
  onEdit?: (item: T) => void
  onDelete?: (item: T) => void
  emptyMessage?: string
}

export function DataTable<T extends { id: string }>({
  data,
  columns,
  onEdit,
  onDelete,
  emptyMessage = "داده‌ای یافت نشد",
}: DataTableProps<T>) {
  if (data.length === 0) {
    return (
      <div className="glass-card p-12 text-center">
        <p className="text-muted-foreground">{emptyMessage}</p>
      </div>
    )
  }

  return (
    <div className="glass-card overflow-hidden">
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead>
            <tr className="border-b border-border/50">
              {columns.map((col) => (
                <th
                  key={String(col.key)}
                  className={cn("px-6 py-4 text-right text-sm font-medium text-muted-foreground", col.className)}
                >
                  {col.header}
                </th>
              ))}
              {(onEdit || onDelete) && (
                <th className="px-6 py-4 text-right text-sm font-medium text-muted-foreground">عملیات</th>
              )}
            </tr>
          </thead>
          <tbody className="divide-y divide-border/30">
            {data.map((item) => (
              <tr key={item.id} className="hover:bg-muted/30 transition-colors">
                {columns.map((col) => (
                  <td key={String(col.key)} className={cn("px-6 py-4 text-sm text-foreground", col.className)}>
                    {col.render ? col.render(item) : String(item[col.key as keyof T] ?? "")}
                  </td>
                ))}
                {(onEdit || onDelete) && (
                  <td className="px-6 py-4">
                    <div className="flex gap-2">
                      {onEdit && (
                        <button onClick={() => onEdit(item)} className="text-primary hover:text-primary/80 text-sm">
                          ویرایش
                        </button>
                      )}
                      {onDelete && (
                        <button
                          onClick={() => onDelete(item)}
                          className="text-destructive hover:text-destructive/80 text-sm"
                        >
                          حذف
                        </button>
                      )}
                    </div>
                  </td>
                )}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
