"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { type Invoice, serviceTypeLabels } from "@/lib/types"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

interface InvoiceModalProps {
  open: boolean
  onClose: () => void
  onSave: (invoice: Omit<Invoice, "id" | "total" | "user_id" | "created_at">) => void
  invoice?: Invoice
}

export function InvoiceModal({ open, onClose, onSave, invoice }: InvoiceModalProps) {
  const [formData, setFormData] = useState({
    customer_name: "",
    project_name: "",
    service_type: "CNC" as Invoice["service_type"],
    area: 0,
    unit_price: 0,
    discount: 0,
    date: "",
    notes: "",
  })

  useEffect(() => {
    if (invoice) {
      setFormData({
        customer_name: invoice.customer_name,
        project_name: invoice.project_name,
        service_type: invoice.service_type,
        area: invoice.area,
        unit_price: invoice.unit_price,
        discount: invoice.discount,
        date: invoice.date,
        notes: invoice.notes || "",
      })
    } else {
      setFormData({
        customer_name: "",
        project_name: "",
        service_type: "CNC",
        area: 0,
        unit_price: 0,
        discount: 0,
        date: "",
        notes: "",
      })
    }
  }, [invoice, open])

  const calculatedTotal = formData.area * formData.unit_price - formData.discount

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    onSave(formData)
    onClose()
  }

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="glass-card border-border/50 max-w-lg">
        <DialogHeader>
          <DialogTitle className="text-foreground">{invoice ? "ویرایش فاکتور" : "فاکتور جدید"}</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label className="text-muted-foreground">نام مشتری</Label>
              <Input
                value={formData.customer_name}
                onChange={(e) => setFormData((prev) => ({ ...prev, customer_name: e.target.value }))}
                className="bg-input border-border/50"
                required
              />
            </div>
            <div className="space-y-2">
              <Label className="text-muted-foreground">نام پروژه</Label>
              <Input
                value={formData.project_name}
                onChange={(e) => setFormData((prev) => ({ ...prev, project_name: e.target.value }))}
                className="bg-input border-border/50"
                required
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label className="text-muted-foreground">نوع خدمات</Label>
              <Select
                value={formData.service_type}
                onValueChange={(value: Invoice["service_type"]) =>
                  setFormData((prev) => ({ ...prev, service_type: value }))
                }
              >
                <SelectTrigger className="bg-input border-border/50">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-popover border-border/50">
                  {Object.entries(serviceTypeLabels).map(([key, label]) => (
                    <SelectItem key={key} value={key}>
                      {label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label className="text-muted-foreground">تاریخ</Label>
              <Input
                value={formData.date}
                onChange={(e) => setFormData((prev) => ({ ...prev, date: e.target.value }))}
                placeholder="۱۴۰۲/۱۰/۱۵"
                className="bg-input border-border/50"
                required
              />
            </div>
          </div>

          <div className="grid grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label className="text-muted-foreground">مساحت/تعداد</Label>
              <Input
                type="number"
                value={formData.area}
                onChange={(e) => setFormData((prev) => ({ ...prev, area: Number(e.target.value) }))}
                className="bg-input border-border/50"
                required
              />
            </div>
            <div className="space-y-2">
              <Label className="text-muted-foreground">قیمت واحد</Label>
              <Input
                type="number"
                value={formData.unit_price}
                onChange={(e) => setFormData((prev) => ({ ...prev, unit_price: Number(e.target.value) }))}
                className="bg-input border-border/50"
                required
              />
            </div>
            <div className="space-y-2">
              <Label className="text-muted-foreground">تخفیف</Label>
              <Input
                type="number"
                value={formData.discount}
                onChange={(e) => setFormData((prev) => ({ ...prev, discount: Number(e.target.value) }))}
                className="bg-input border-border/50"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label className="text-muted-foreground">توضیحات</Label>
            <Textarea
              value={formData.notes}
              onChange={(e) => setFormData((prev) => ({ ...prev, notes: e.target.value }))}
              className="bg-input border-border/50 min-h-[80px]"
            />
          </div>

          <div className="p-4 rounded-xl bg-primary/10 border border-primary/20">
            <div className="flex justify-between items-center">
              <span className="text-muted-foreground">جمع کل:</span>
              <span className="text-2xl font-bold text-primary">
                {new Intl.NumberFormat("fa-AF").format(calculatedTotal)} ؋
              </span>
            </div>
          </div>

          <div className="flex gap-3 pt-4">
            <Button type="submit" className="flex-1 bg-primary text-primary-foreground hover:bg-primary/90">
              {invoice ? "ذخیره تغییرات" : "ثبت فاکتور"}
            </Button>
            <Button type="button" variant="outline" onClick={onClose} className="border-border/50 bg-transparent">
              انصراف
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  )
}
