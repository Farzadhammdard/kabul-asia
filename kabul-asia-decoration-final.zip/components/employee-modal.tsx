"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { type Employee, formatNumber } from "@/lib/types"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"

interface EmployeeModalProps {
  open: boolean
  onClose: () => void
  onSave: (employee: Omit<Employee, "id" | "calculated_salary" | "user_id" | "created_at">) => void
  employee?: Employee
}

export function EmployeeModal({ open, onClose, onSave, employee }: EmployeeModalProps) {
  const [formData, setFormData] = useState({
    name: "",
    base_salary: 0,
    attendance_days: 26,
  })

  useEffect(() => {
    if (employee) {
      setFormData({
        name: employee.name,
        base_salary: employee.base_salary,
        attendance_days: employee.attendance_days,
      })
    } else {
      setFormData({
        name: "",
        base_salary: 0,
        attendance_days: 26,
      })
    }
  }, [employee, open])

  const calculatedSalary = (formData.base_salary / 26) * formData.attendance_days

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    onSave(formData)
    onClose()
  }

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="glass-card border-border/50 max-w-md">
        <DialogHeader>
          <DialogTitle className="text-foreground">{employee ? "ویرایش کارمند" : "کارمند جدید"}</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label className="text-muted-foreground">نام کارمند</Label>
            <Input
              value={formData.name}
              onChange={(e) => setFormData((prev) => ({ ...prev, name: e.target.value }))}
              className="bg-input border-border/50"
              required
            />
          </div>

          <div className="space-y-2">
            <Label className="text-muted-foreground">حقوق پایه ماهانه (افغانی)</Label>
            <Input
              type="number"
              value={formData.base_salary}
              onChange={(e) => setFormData((prev) => ({ ...prev, base_salary: Number(e.target.value) }))}
              className="bg-input border-border/50"
              required
            />
          </div>

          <div className="space-y-2">
            <Label className="text-muted-foreground">روزهای حضور (از ۲۶ روز)</Label>
            <Input
              type="number"
              min={0}
              max={26}
              value={formData.attendance_days}
              onChange={(e) => setFormData((prev) => ({ ...prev, attendance_days: Number(e.target.value) }))}
              className="bg-input border-border/50"
              required
            />
          </div>

          <div className="p-4 rounded-xl bg-primary/10 border border-primary/20">
            <div className="flex justify-between items-center">
              <span className="text-muted-foreground">حقوق محاسبه شده:</span>
              <span className="text-xl font-bold text-primary">{formatNumber(calculatedSalary)} ؋</span>
            </div>
            <p className="text-xs text-muted-foreground mt-2">فرمول: (حقوق پایه ÷ ۲۶) × روزهای حضور</p>
          </div>

          <div className="flex gap-3 pt-4">
            <Button type="submit" className="flex-1 bg-primary text-primary-foreground hover:bg-primary/90">
              {employee ? "ذخیره تغییرات" : "ثبت کارمند"}
            </Button>
            <Button type="button" variant="outline" onClick={onClose} className="border-border/50 bg-transparent">
              انصراف
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  )
}
