"use client"

import { useState } from "react"
import Link from "next/link"
import { usePathname, useRouter } from "next/navigation"
import { cn } from "@/lib/utils"
import { useAuth } from "@/lib/auth-context"
import { LayoutDashboard, FileText, Wallet, Users, Settings, LogOut, Menu, X, Sparkles, Hammer } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"

const navItems = [
  { href: "/dashboard", label: "داشبورد", icon: LayoutDashboard },
  { href: "/dashboard/services", label: "خدمات", icon: FileText },
  { href: "/dashboard/expenses", label: "هزینه‌ها", icon: Wallet },
  { href: "/dashboard/employees", label: "کارکنان", icon: Users },
  { href: "/dashboard/ai-analysis", label: "تحلیل هوشمند", icon: Sparkles },
  { href: "/dashboard/settings", label: "تنظیمات", icon: Settings, adminOnly: true },
]

function NavContent({ onItemClick }: { onItemClick?: () => void }) {
  const pathname = usePathname()
  const router = useRouter()
  const { profile, signOut, isAdmin, isLoading } = useAuth()

  const filteredItems = navItems.filter((item) => !item.adminOnly || isAdmin)

  const handleLogout = async () => {
    await signOut()
    onItemClick?.()
    router.push("/")
    router.refresh()
  }

  return (
    <div className="flex flex-col h-full">
      {/* Logo */}
      <div className="p-6 border-b border-sidebar-border/50">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-primary/20 flex items-center justify-center">
            <Hammer className="w-5 h-5 text-primary" />
          </div>
          <div>
            <h1 className="font-bold text-foreground">کابل آسیا</h1>
            <p className="text-xs text-muted-foreground">دکوراسیون</p>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 p-4 space-y-2">
        {filteredItems.map((item) => {
          const isActive = pathname === item.href
          return (
            <Link
              key={item.href}
              href={item.href}
              onClick={onItemClick}
              className={cn(
                "flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200",
                isActive
                  ? "bg-primary/20 text-primary"
                  : "text-muted-foreground hover:bg-sidebar-accent hover:text-foreground",
              )}
            >
              <item.icon className="w-5 h-5" />
              <span className="font-medium">{item.label}</span>
            </Link>
          )
        })}
      </nav>

      {/* User section */}
      {!isLoading && profile && (
        <div className="p-4 border-t border-sidebar-border/50">
          <div className="flex items-center gap-3 px-4 py-3 rounded-xl bg-sidebar-accent/50">
            <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center">
              <span className="text-primary font-bold">{profile.name[0]}</span>
            </div>
            <div className="flex-1 min-w-0">
              <p className="font-medium text-sm text-foreground truncate">{profile.name}</p>
              <p className="text-xs text-muted-foreground">{profile.role === "Admin" ? "مدیر" : "اپراتور"}</p>
            </div>
            <Button
              variant="ghost"
              size="icon"
              onClick={handleLogout}
              className="text-muted-foreground hover:text-destructive"
            >
              <LogOut className="w-4 h-4" />
            </Button>
          </div>
        </div>
      )}
    </div>
  )
}

export function Sidebar() {
  const [mobileOpen, setMobileOpen] = useState(false)

  return (
    <>
      {/* Desktop Sidebar */}
      <aside className="hidden lg:flex w-72 h-screen glass-sidebar fixed right-0 top-0 flex-col z-40">
        <NavContent />
      </aside>

      {/* Mobile Header */}
      <header className="lg:hidden fixed top-0 right-0 left-0 h-16 glass-card z-50 flex items-center justify-between px-4">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-primary/20 flex items-center justify-center">
            <Hammer className="w-4 h-4 text-primary" />
          </div>
          <span className="font-bold text-foreground">کابل آسیا</span>
        </div>
        <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
          <SheetTrigger asChild>
            <Button variant="ghost" size="icon">
              {mobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </Button>
          </SheetTrigger>
          <SheetContent side="right" className="w-72 p-0 glass-sidebar border-sidebar-border/50">
            <NavContent onItemClick={() => setMobileOpen(false)} />
          </SheetContent>
        </Sheet>
      </header>
    </>
  )
}
