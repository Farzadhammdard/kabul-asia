"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { type Expense, categoryLabels } from "@/lib/types"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

interface ExpenseModalProps {
  open: boolean
  onClose: () => void
  onSave: (expense: Omit<Expense, "id" | "user_id" | "created_at">) => void
  expense?: Expense
}

export function ExpenseModal({ open, onClose, onSave, expense }: ExpenseModalProps) {
  const [formData, setFormData] = useState({
    title: "",
    amount: 0,
    category: "General" as Expense["category"],
    date: "",
  })

  useEffect(() => {
    if (expense) {
      setFormData({
        title: expense.title,
        amount: expense.amount,
        category: expense.category,
        date: expense.date,
      })
    } else {
      setFormData({
        title: "",
        amount: 0,
        category: "General",
        date: "",
      })
    }
  }, [expense, open])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    onSave(formData)
    onClose()
  }

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="glass-card border-border/50 max-w-md">
        <DialogHeader>
          <DialogTitle className="text-foreground">{expense ? "ویرایش هزینه" : "هزینه جدید"}</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label className="text-muted-foreground">عنوان</Label>
            <Input
              value={formData.title}
              onChange={(e) => setFormData((prev) => ({ ...prev, title: e.target.value }))}
              className="bg-input border-border/50"
              required
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label className="text-muted-foreground">مبلغ</Label>
              <Input
                type="number"
                value={formData.amount}
                onChange={(e) => setFormData((prev) => ({ ...prev, amount: Number(e.target.value) }))}
                className="bg-input border-border/50"
                required
              />
            </div>
            <div className="space-y-2">
              <Label className="text-muted-foreground">دسته‌بندی</Label>
              <Select
                value={formData.category}
                onValueChange={(value: Expense["category"]) => setFormData((prev) => ({ ...prev, category: value }))}
              >
                <SelectTrigger className="bg-input border-border/50">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-popover border-border/50">
                  {Object.entries(categoryLabels).map(([key, label]) => (
                    <SelectItem key={key} value={key}>
                      {label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <Label className="text-muted-foreground">تاریخ</Label>
            <Input
              value={formData.date}
              onChange={(e) => setFormData((prev) => ({ ...prev, date: e.target.value }))}
              placeholder="۱۴۰۲/۱۰/۱۵"
              className="bg-input border-border/50"
              required
            />
          </div>

          <div className="flex gap-3 pt-4">
            <Button type="submit" className="flex-1 bg-primary text-primary-foreground hover:bg-primary/90">
              {expense ? "ذخیره تغییرات" : "ثبت هزینه"}
            </Button>
            <Button type="button" variant="outline" onClick={onClose} className="border-border/50 bg-transparent">
              انصراف
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  )
}
